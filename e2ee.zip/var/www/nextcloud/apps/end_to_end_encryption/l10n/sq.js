OC.L10N.register(
    "end_to_end_encryption",
    {
    "Internal error" : "Error i brendshëm",
    "You are not allowed to delete this private key" : "Nuk je i lejuar të fshish këtë çelës privat",
    "You are not allowed to remove the lock" : "Nuk je i lejuar të fshish kyçjen",
    "File not locked" : "Skedari nuk është i kyçur"
},
"nplurals=2; plural=(n != 1);");
