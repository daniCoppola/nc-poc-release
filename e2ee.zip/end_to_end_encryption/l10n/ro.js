OC.L10N.register(
    "end_to_end_encryption",
    {
    "Internal error" : "Eroare internă",
    "End-to-End Encryption" : "Criptare integrală"
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");
